ABOUT:
- ATMAA PAN Module.
- This module asks the user to enter their PAN details and stores it in a .csv file for future reference.
- Multiple user details can be added.
- All user details are stored in same .csv file. (PAN_DETAILS.csv)

WHAT'S NEW:
- [BUG FIXED] Clicking Submit button without entering details shows the 'Data successfully saved' dialog box. 

GETTING STARTED:
- Run the pan_module_v2.0.exe file in the panmodule folder.

KNOWN BUGS:
- DOB (Date of Birth) must be entered in DD-MM-YYYY format with or without '/'. No 'Datepicker/Calendar' available yet.

Made for Atmanirbhar Business Consultancy LLP 